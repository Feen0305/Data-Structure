# DBMS-Represent-by-C

✨ New : Graph function ( Shortest Path , BFS , DFS )

Function to use 👍

```c
void GetShortestPathOF(Node *Initial_vertex_HEADER, Node *Terminal_vertex_HEADER, Node* weight_HEADER);

void GetBFS(Node *Initial_vertex_HEADER, Node *Terminal_vertex_HEADER, Node* weight_HEADER);

void GetDFS(Node *Initial_vertex_HEADER, Node *Terminal_vertex_HEADER, Node* weight_HEADER);
```

- source and destination รับ input ใน function แล้ว

- ใส่ input เข้ามาแค่ *Initial_vertex_HEADER , *Terminal_vertex_HEADER, *weight_HEADER
  
- GetBFS , GetDFS ต้องใส่ *weight_HEADER เข้ามาด้วย เพราะใช้ weight เป็นเกณฑ์ในการ traversal

Shortest Path 💯 

![image](https://github.com/DarkTouiZ/DBMS-Represent-by-C/assets/118984693/bb304016-7689-4c32-891b-63a32f5c5051)

BFS 💯 

![image](https://github.com/DarkTouiZ/DBMS-Represent-by-C/assets/118984693/19e6624c-0e8a-4592-85e6-f004aee16b06)

DFS 💯 

![image](https://github.com/DarkTouiZ/DBMS-Represent-by-C/assets/118984693/950a8747-686c-46ba-ade2-4e448d746648)

by Feen
